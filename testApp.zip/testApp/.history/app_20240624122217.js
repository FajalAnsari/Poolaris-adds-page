const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const cors = require('cors');
const { default: axios } = require('axios');
// Proxy middleware configuration
app.use(express.json()) 

// Use the proxy for your API routes
// app.use('/proxy', createProxyMiddleware({
//     target: 'http://192.168.0.21:8081/escpos_test/arabic_test_kot.php', // Replace with your local server URL and port
//     changeOrigin: true, // Needed for virtual hosted sites
//     pathRewrite: {
//       '^/proxy': '', // Remove the /proxy prefix when forwarding the request
//     },
//   }));

app.use(cors())
app.post('/proxy', async (req,res)=>{
  const target =  req.body.cloud_agent_local_url
  console.log(target)
  try{ 
    const test = await axios.post(target,req)
  }catch(error){
    if (error.code === 'ECONNABORTED') {
      console.error('Request stream has been aborted:', error.message);
      res.status(499).send('Client closed request');
    } else {
      console.error('Error forwarding request:', error.message);
      res.status(500).send('An error occurred while forwarding the request.');
    }
  }
  res.json({msg:"ok"})
})  
// Start the server
const port = process.env.PORT || 3000; // Choose a port for your proxy server
app.listen(port, () => {
  console.log(`Proxy server listening on port ${port}`);
});